"""
dashboard_server.py — Dagrapport-dashboard voor TTS, QFS en RVB

VERVANGT (9 sep 2026) het eerdere TTS-monitordashboard. Toont per dag:
tijdlijn van de handelsdag, scorekaarten per strategie, alle trades
met grafiek en detail, en de RVB-signalen die géén trade werden.
Doel: de Telegram-stroom terugbrengen tot alleen alarmen.

Bronnen (alleen lezen):
    logs/trade_journal.csv      -- afgeronde trades (journal_module.py)
    logs/charts/*.png           -- grafieken (chart_module.py)
    logs/rvb_signals.jsonl      -- RVB-signalen incl. overgeslagen (rvb_scan.py)
    state.json                  -- gesimuleerd saldo (state_module.py)

Uitsluitend Python-stdlib (http.server), geen extra dependencies.
Luistert ALLEEN op 127.0.0.1:8899 -- Caddy (zie Caddyfile.ibkr) zet er
HTTPS + basic-auth voor, exact zoals bij de HBAR-bot.

Routes:
    /                      dagrapport van vandaag
    /?date=2026-09-09      dagrapport van een andere dag
    /charts/<bestand>.png  grafiek
    /api/day?date=...      dezelfde data als JSON
    /health                voor monitoring

Starten: via systemd (ibkr-dashboard.service) of handmatig:
    cd /opt/strategy && python3 dashboard_server.py
"""

from __future__ import annotations

import csv
import html
import json
import os
import sys
from collections import defaultdict
from datetime import date, datetime, timedelta, timezone
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

STRATEGY_DIR = os.environ.get("STRATEGY_DIR", "/opt/strategy")
LOGS_DIR = os.path.join(STRATEGY_DIR, "logs")
JOURNAL_PATH = os.environ.get("TTS_JOURNAL_FILE", os.path.join(LOGS_DIR, "trade_journal.csv"))
CHARTS_DIR = os.path.join(LOGS_DIR, "charts")
SIGNALS_PATH = os.environ.get("RVB_SIGNAL_LOG", os.path.join(LOGS_DIR, "rvb_signals.jsonl"))
STATE_PATH = os.environ.get("TTS_STATE_FILE", os.path.join(STRATEGY_DIR, "state.json"))
HOST = os.environ.get("DASHBOARD_BIND", "127.0.0.1")   # 0.0.0.0 alleen in de Docker-Caddy-situatie, zie DASHBOARD_DEPLOY.md
PORT = int(os.environ.get("DASHBOARD_PORT", "8899"))

STRATEGIES = {
    "TTS": ("Touch & Turn", "eerste 90 min"),
    "QFS": ("Quick Flip", "eerste 90 min"),
    "RVB": ("Relative Volume Breakout", "hele dag"),
}
RESULT_LABELS = {
    "take_profit_hit": "Take-profit", "stop_loss_hit": "Stop-loss",
    "forced_close_90min": "Geforceerd (tijdslimiet)", "unknown": "Onbekend",
}
SESSION_START_MIN = 15 * 60 + 30   # 15:30 CEST
SESSION_END_MIN = 22 * 60          # 22:00 CEST
WEEKDAGEN = ["maandag", "dinsdag", "woensdag", "donderdag", "vrijdag", "zaterdag", "zondag"]
MAANDEN = ["", "januari", "februari", "maart", "april", "mei", "juni", "juli", "augustus", "september", "oktober", "november", "december"]


# ---------------------------------------------------------------------------
# Data laden
# ---------------------------------------------------------------------------

def _f(x, default=None):
    try:
        return float(x)
    except (TypeError, ValueError):
        return default


def _local_time_from_utc(d: str, t: str) -> str:
    """Oude journal-rijen hebben alleen een UTC-tijd; zet om naar servertijd (CEST)."""
    try:
        utc = datetime.fromisoformat(f"{d}T{t}").replace(tzinfo=timezone.utc)
        return utc.astimezone().strftime("%H:%M")
    except ValueError:
        return t[:5]


def load_trades() -> list[dict]:
    if not os.path.exists(JOURNAL_PATH):
        return []
    trades = []
    with open(JOURNAL_PATH, newline="") as f:
        for r in csv.DictReader(f):
            strategy = (r.get("strategy") or "").strip()
            if not strategy:
                strategy = (r.get("oca_group") or "TTS_").split("_", 1)[0]
            if strategy not in STRATEGIES:
                strategy = "TTS"
            entry = _f(r.get("entry_price"), 0.0)
            sl = _f(r.get("stop_loss"), 0.0)
            qty = _f(r.get("quantity"), 0.0)
            pnl_net = _f(r.get("pnl_net"))
            pnl = pnl_net if pnl_net is not None else _f(r.get("pnl_estimate"), 0.0)
            risk = abs(entry - sl) * qty
            entry_time = (r.get("entry_time") or "")[:5] or _local_time_from_utc(r.get("date", ""), r.get("time", "00:00:00"))
            exit_time = (r.get("exit_time") or "")[:5] or _local_time_from_utc(r.get("date", ""), r.get("time", "00:00:00"))
            trades.append({
                "date": r.get("date", ""), "strategy": strategy, "symbol": r.get("symbol", ""),
                "direction": r.get("direction", ""), "entry_price": entry,
                "take_profit": _f(r.get("take_profit"), 0.0), "stop_loss": sl, "quantity": qty,
                "exit_price": _f(r.get("exit_price")), "result": r.get("result", "unknown"),
                "pnl": pnl, "pnl_gross": _f(r.get("pnl_estimate")), "fees": _f(r.get("fees")),
                "r_multiple": (pnl / risk) if risk > 0 else None, "risk": risk,
                "entry_time": entry_time, "exit_time": exit_time,
                "oca_group": r.get("oca_group", ""), "chart": r.get("chart", ""),
                "note": r.get("pnl_note", ""),
            })
    return trades


def load_signals(day: str) -> list[dict]:
    if not os.path.exists(SIGNALS_PATH):
        return []
    out = []
    with open(SIGNALS_PATH) as f:
        for line in f:
            try:
                s = json.loads(line)
            except json.JSONDecodeError:
                continue
            if s.get("time", "").startswith(day):
                out.append(s)
    return out


def load_balance() -> float | None:
    try:
        with open(STATE_PATH) as f:
            return float(json.load(f).get("simulated_balance"))
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Samenvatten
# ---------------------------------------------------------------------------

def summarize(trades: list[dict]) -> dict:
    n = len(trades)
    wins = sum(1 for t in trades if t["pnl"] > 0)
    pnl = sum(t["pnl"] for t in trades)
    rs = [t["r_multiple"] for t in trades if t["r_multiple"] is not None]
    return {"trades": n, "wins": wins, "losses": n - wins, "pnl": round(pnl, 2),
            "winrate": round(100 * wins / n) if n else None,
            "avg_r": round(sum(rs) / len(rs), 2) if rs else None}


def build_day(day: date, all_trades: list[dict]) -> dict:
    iso = day.isoformat()
    monday = day - timedelta(days=day.weekday())
    day_trades = [t for t in all_trades if t["date"] == iso]
    week_trades = [t for t in all_trades if monday.isoformat() <= t["date"] <= iso]
    trading_days = sorted({t["date"] for t in all_trades if t["date"] <= iso})[-20:]
    d20_trades = [t for t in all_trades if t["date"] in trading_days]

    per_strategy = {}
    for code in STRATEGIES:
        mine = lambda ts: [t for t in ts if t["strategy"] == code]
        first = min((t["date"] for t in all_trades if t["strategy"] == code), default=None)
        per_strategy[code] = {
            "day": summarize(mine(day_trades)), "week": summarize(mine(week_trades)),
            "d20": summarize(mine(d20_trades)), "first_date": first,
        }

    signals = load_signals(iso)
    dates = sorted({t["date"] for t in all_trades})
    prev_days = [d for d in dates if d < iso]
    next_days = [d for d in dates if d > iso]
    return {
        "date": iso, "trades": sorted(day_trades, key=lambda t: t["entry_time"]),
        "total": summarize(day_trades), "week": summarize(week_trades),
        "per_strategy": per_strategy, "balance": load_balance(),
        "signals_skipped": [s for s in signals if s.get("status") == "skipped"],
        "prev_date": prev_days[-1] if prev_days else None, "next_date": next_days[0] if next_days else None,
        "generated_at": datetime.now().strftime("%H:%M"),
    }


# ---------------------------------------------------------------------------
# HTML
# ---------------------------------------------------------------------------

CSS = """
:root{--paper:#eef1f4;--sheet:#fff;--ink:#18232e;--ink-2:#4c5a68;--ink-3:#8a97a4;--rule:#d6dce3;--tts:#2457a6;--qfs:#7a3e9d;--rvb:#0f8a78;--win:#1e8e5a;--loss:#c0392b;--flat:#8a97a4}
*{box-sizing:border-box}body{margin:0;background:var(--paper);color:var(--ink);font-family:"Segoe UI",-apple-system,"Helvetica Neue",Arial,sans-serif;font-size:15px;line-height:1.45;font-variant-numeric:tabular-nums}
.page{max-width:1040px;margin:0 auto;padding:28px 20px 60px}
header{display:flex;align-items:baseline;justify-content:space-between;gap:16px;flex-wrap:wrap;margin-bottom:8px}header h1{font-size:26px;font-weight:600;margin:0;letter-spacing:-.01em}
.daynav{display:flex;gap:6px}.daynav a,.daynav span{border:1px solid var(--rule);background:var(--sheet);border-radius:6px;padding:5px 12px;color:var(--ink-2);text-decoration:none}.daynav span{opacity:.45}.daynav a:hover,.daynav a:focus-visible{border-color:var(--ink-2);color:var(--ink);outline:none}
.daytotal{font-size:15px;color:var(--ink-2);margin:0 0 24px}.daytotal strong{font-size:20px;font-weight:600;margin-right:6px}
.pos{color:var(--win)}.neg{color:var(--loss)}.zero{color:var(--flat)}
.timeline{background:var(--sheet);border:1px solid var(--rule);border-radius:10px;padding:18px 20px 12px;margin-bottom:20px}.timeline h2{font-size:14px;font-weight:600;color:var(--ink-2);margin:0 0 12px}.timeline svg{width:100%;height:auto;display:block}.timeline text{font-size:11px;fill:var(--ink-3)}.tick{stroke:var(--rule)}
.bar{rx:3}.bar.TTS{fill:var(--tts)}.bar.QFS{fill:var(--qfs)}.bar.RVB{fill:var(--rvb)}.bar.loss{opacity:.45}
.legend{display:flex;gap:18px;font-size:12px;color:var(--ink-2);margin-top:6px;flex-wrap:wrap}.legend span::before{content:"";display:inline-block;width:10px;height:10px;border-radius:2px;margin-right:6px;vertical-align:-1px}.legend .TTS::before{background:var(--tts)}.legend .QFS::before{background:var(--qfs)}.legend .RVB::before{background:var(--rvb)}.legend .dim::before{background:var(--ink-3);opacity:.45}
.scores{display:grid;grid-template-columns:repeat(3,1fr);gap:14px;margin-bottom:24px}.score{background:var(--sheet);border:1px solid var(--rule);border-left-width:5px;border-radius:10px;padding:14px 16px}.score.TTS{border-left-color:var(--tts)}.score.QFS{border-left-color:var(--qfs)}.score.RVB{border-left-color:var(--rvb)}
.score h3{margin:0;font-size:15px;font-weight:600}.score .sub{color:var(--ink-3);font-size:12px;margin-bottom:10px}.score .pnl{font-size:24px;font-weight:600;line-height:1.1}.score dl{display:grid;grid-template-columns:auto 1fr;gap:2px 12px;margin:10px 0 0;font-size:13px}.score dt{color:var(--ink-3)}.score dd{margin:0;text-align:right}.score .wtd{border-top:1px solid var(--rule);margin-top:10px;padding-top:8px;font-size:12px;color:var(--ink-2)}
.trades h2{font-size:16px;font-weight:600;margin:0 0 10px;display:flex;justify-content:space-between;align-items:baseline}.filters{display:flex;gap:6px}.filters button{border:1px solid var(--rule);background:var(--sheet);border-radius:999px;padding:3px 11px;font:inherit;font-size:12px;cursor:pointer;color:var(--ink-2)}.filters button[aria-pressed=true]{background:var(--ink);color:#fff;border-color:var(--ink)}
.trade{background:var(--sheet);border:1px solid var(--rule);border-radius:10px;margin-bottom:8px;overflow:hidden}.trade summary{list-style:none;cursor:pointer;display:grid;grid-template-columns:8px 52px 44px 70px 1fr 150px 90px 24px;align-items:center;gap:12px;padding:10px 14px 10px 0}.trade summary::-webkit-details-marker{display:none}.trade summary:focus-visible{outline:2px solid var(--ink-2);outline-offset:-2px}
.swatch{align-self:stretch}.trade.TTS .swatch{background:var(--tts)}.trade.QFS .swatch{background:var(--qfs)}.trade.RVB .swatch{background:var(--rvb)}
.t-time{color:var(--ink-2);font-size:13px}.t-strat{font-size:12px;font-weight:600;letter-spacing:.02em}.trade.TTS .t-strat{color:var(--tts)}.trade.QFS .t-strat{color:var(--qfs)}.trade.RVB .t-strat{color:var(--rvb)}.t-sym{font-weight:600}.t-desc{color:var(--ink-2);font-size:13px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.t-result{font-size:13px}.t-pnl{text-align:right;font-weight:600}.chev{color:var(--ink-3);transition:transform .15s}.trade[open] .chev{transform:rotate(90deg)}
.detail{display:grid;grid-template-columns:1fr 260px;gap:18px;padding:4px 14px 16px 20px;border-top:1px solid var(--rule)}.detail figure{margin:0}.detail img{width:100%;height:auto;border:1px solid var(--rule);border-radius:6px;background:#fbfcfd}.detail .nochart{border:1px dashed var(--rule);border-radius:6px;padding:40px;text-align:center;color:var(--ink-3);font-size:13px}.detail dl{display:grid;grid-template-columns:auto 1fr;gap:3px 14px;font-size:13px;margin:8px 0 0}.detail dt{color:var(--ink-3)}.detail dd{margin:0}.detail .note{font-size:13px;color:var(--ink-2);margin-top:12px;padding-top:10px;border-top:1px solid var(--rule)}
.empty{background:var(--sheet);border:1px dashed var(--rule);border-radius:10px;padding:26px;color:var(--ink-3);text-align:center}
.signals{margin-top:26px;font-size:13px;color:var(--ink-2)}.signals h2{font-size:14px;font-weight:600;margin:0 0 6px;color:var(--ink-2)}.signals ul{margin:0;padding-left:18px}
.footer{margin-top:30px;font-size:12px;color:var(--ink-3)}
@media(max-width:720px){.scores{grid-template-columns:1fr}.trade summary{grid-template-columns:8px 46px 40px 56px 1fr 70px 20px}.t-result{display:none}.detail{grid-template-columns:1fr}}
@media(prefers-reduced-motion:reduce){.chev{transition:none}}
"""

JS = """
document.querySelectorAll('.filters button').forEach(b=>b.addEventListener('click',()=>{
  document.querySelectorAll('.filters button').forEach(x=>x.setAttribute('aria-pressed',x===b));
  const f=b.dataset.f;document.querySelectorAll('.trade').forEach(t=>{t.style.display=(f==='all'||t.classList.contains(f))?'':'none';});
}));
"""


def eur(x: float | None, sign: bool = True) -> str:
    if x is None:
        return "–"
    s = f"{x:+,.2f}" if sign else f"{x:,.2f}"
    return "€" + s.replace(",", "X").replace(".", ",").replace("X", ".")


def cls(x: float | None) -> str:
    return "zero" if not x else ("pos" if x > 0 else "neg")


def _min(hhmm: str) -> int | None:
    try:
        h, m = hhmm.split(":")[:2]
        return int(h) * 60 + int(m)
    except ValueError:
        return None


def timeline_svg(trades: list[dict]) -> str:
    x0, x1, y0 = 40, 1000, 80
    px_per_min = (x1 - x0) / (SESSION_END_MIN - SESSION_START_MIN)
    max_abs = max((abs(t["pnl"]) for t in trades), default=1) or 1
    parts = ['<svg viewBox="0 0 1000 150" role="img" aria-label="Trades uitgezet in de tijd, hoogte is resultaat">']
    for h in range(SESSION_START_MIN, SESSION_END_MIN + 1, 60):
        x = x0 + (h - SESSION_START_MIN) * px_per_min
        parts.append(f'<line class="tick" x1="{x:.1f}" y1="20" x2="{x:.1f}" y2="118"/><text x="{x:.1f}" y="135">{h // 60:02d}:{h % 60:02d}</text>')
    parts.append(f'<rect x="{x0}" y="20" width="{60 * px_per_min:.1f}" height="98" fill="#0f8a78" opacity=".06"/><text x="{x0 + 6}" y="32" fill="#0f8a78">ORB</text>')
    parts.append(f'<rect x="{x0}" y="20" width="{90 * px_per_min:.1f}" height="98" fill="#2457a6" opacity=".05"/><text x="{x0 + 60 * px_per_min + 8:.1f}" y="32" fill="#2457a6">90-min TTS/QFS</text>')
    parts.append(f'<line x1="{x0}" y1="{y0}" x2="{x1}" y2="{y0}" stroke="#8a97a4"/>')
    for t in trades:
        a, b = _min(t["entry_time"]), _min(t["exit_time"])
        if a is None:
            continue
        b = b if b is not None and b > a else a + 5
        x = x0 + (a - SESSION_START_MIN) * px_per_min
        w = max(6.0, (b - a) * px_per_min)
        hgt = max(4.0, 56 * abs(t["pnl"]) / max_abs)
        y = y0 - hgt if t["pnl"] >= 0 else y0
        loss = " loss" if t["pnl"] < 0 else ""
        title = html.escape(f"{t['strategy']} {t['symbol']} {t['direction']} {t['entry_time']}–{t['exit_time']} {eur(t['pnl'])}")
        parts.append(f'<rect class="bar {t["strategy"]}{loss}" x="{x:.1f}" y="{y:.1f}" width="{w:.1f}" height="{hgt:.1f}"><title>{title}</title></rect>')
    parts.append("</svg>")
    return "".join(parts)


def trade_html(t: dict) -> str:
    e = html.escape
    res = RESULT_LABELS.get(t["result"], t["result"])
    desc = f"{t['direction']} {t['quantity']:g} × {eur(t['entry_price'], sign=False)} · TP {t['take_profit']:.2f} / SL {t['stop_loss']:.2f}"
    chart = (f'<img src="/charts/{e(t["chart"])}" alt="Grafiek {e(t["symbol"])}" loading="lazy">' if t["chart"]
             else '<div class="nochart">Geen grafiek voor deze trade</div>')
    r = f"{t['r_multiple']:+.1f} R" if t["r_multiple"] is not None else "–"
    fees = f"{eur(t['pnl_gross'])} / {eur(-t['fees']) if t['fees'] is not None else '–'}"
    exit_p = f"{t['exit_time']} @ {t['exit_price']:.2f}" if t["exit_price"] is not None else t["exit_time"]
    return f"""<details class="trade {t['strategy']}">
<summary><span class="swatch"></span><span class="t-time">{e(t['entry_time'])}</span><span class="t-strat">{t['strategy']}</span><span class="t-sym">{e(t['symbol'])}</span>
<span class="t-desc">{e(desc)}</span><span class="t-result {cls(t['pnl'])}">{e(res)} {e(t['exit_time'])}</span><span class="t-pnl {cls(t['pnl'])}">{eur(t['pnl'])}</span><span class="chev">›</span></summary>
<div class="detail"><figure>{chart}</figure><div><dl>
<dt>Entry</dt><dd>{e(t['entry_time'])} @ {t['entry_price']:.2f}</dd><dt>Exit</dt><dd>{e(exit_p)}</dd>
<dt>Risico</dt><dd>{eur(t['risk'], sign=False)} · {r}</dd><dt>Bruto / fees</dt><dd>{fees}</dd><dt>OCA</dt><dd>{e(t['oca_group']) or '–'}</dd></dl>
{f'<p class="note">{e(t["note"])}</p>' if t['note'] else ''}</div></div></details>"""


def render(d: dict) -> str:
    e = html.escape
    day = date.fromisoformat(d["date"])
    titel = f"{WEEKDAGEN[day.weekday()].capitalize()} {day.day} {MAANDEN[day.month]} {day.year}"
    tot, wk = d["total"], d["week"]
    nav_prev = f'<a href="/?date={d["prev_date"]}">← {d["prev_date"][5:]}</a>' if d["prev_date"] else '<span>← eerder</span>'
    nav_next = f'<a href="/?date={d["next_date"]}">{d["next_date"][5:]} →</a>' if d["next_date"] else '<span>later →</span>'
    saldo = f" · saldo {eur(d['balance'], sign=False)}" if d["balance"] is not None else ""
    daytotal = (f'<strong class="{cls(tot["pnl"])}">{eur(tot["pnl"])}</strong> netto over {tot["trades"]} trades '
                f'({tot["wins"]} winst, {tot["losses"]} verlies){saldo} · week {eur(wk["pnl"])}') if tot["trades"] else "Geen afgeronde trades op deze dag."

    cards = []
    for code, (naam, venster) in STRATEGIES.items():
        s = d["per_strategy"][code]
        dd, ww, d20 = s["day"], s["week"], s["d20"]
        wr = f"{d20['winrate']} % ({d20['trades']} trades)" if d20["winrate"] is not None else "–"
        avg_r = f"{dd['avg_r']:+.1f} R" if dd["avg_r"] is not None else "–"
        sinds = f" · sinds {s['first_date']}" if s["first_date"] else ""
        cards.append(f"""<article class="score {code}"><h3>{e(naam)}</h3><div class="sub">{code} · {venster}</div>
<div class="pnl {cls(dd['pnl'])}">{eur(dd['pnl'])}</div>
<dl><dt>Trades</dt><dd>{dd['trades']} ({dd['wins']} winst)</dd><dt>Gem. R</dt><dd>{avg_r}</dd><dt>Winrate 20d</dt><dd>{wr}</dd></dl>
<div class="wtd">Deze week {eur(ww['pnl'])} · 20 dagen {eur(d20['pnl'])}{sinds}</div></article>""")

    trades = "".join(trade_html(t) for t in d["trades"]) or '<div class="empty">Geen trades. Zodra een trade sluit verschijnt hij hier met grafiek.</div>'
    sig_items = "".join(
        f"<li>{e(s.get('time', '')[11:16])} {e(s.get('symbol', ''))} {e(s.get('direction', ''))} — {e(s.get('reason', 'overgeslagen'))}</li>"
        for s in d["signals_skipped"])
    signals = f'<section class="signals"><h2>RVB-signalen zonder trade ({len(d["signals_skipped"])})</h2><ul>{sig_items}</ul></section>' if sig_items else ""

    return f"""<!DOCTYPE html><html lang="nl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Dagrapport — {e(titel)}</title><style>{CSS}</style></head><body><div class="page">
<header><h1>{e(titel)}</h1><nav class="daynav" aria-label="Dag kiezen">{nav_prev}{nav_next}</nav></header>
<p class="daytotal">{daytotal}</p>
<section class="timeline" aria-label="Verloop van de handelsdag"><h2>Handelsdag 15:30–22:00 CEST</h2>{timeline_svg(d['trades'])}
<div class="legend"><span class="TTS">Touch &amp; Turn</span><span class="QFS">Quick Flip</span><span class="RVB">Relative Volume Breakout</span><span class="dim">Verliestrade (transparant, onder de lijn)</span></div></section>
<section class="scores" aria-label="Resultaat per strategie">{''.join(cards)}</section>
<section class="trades"><h2>Trades van deze dag<div class="filters" role="group" aria-label="Filter op strategie">
<button type="button" aria-pressed="true" data-f="all">Alle</button><button type="button" aria-pressed="false" data-f="TTS">TTS</button><button type="button" aria-pressed="false" data-f="QFS">QFS</button><button type="button" aria-pressed="false" data-f="RVB">RVB</button></div></h2>
{trades}</section>{signals}
<p class="footer">Bron: trade_journal.csv, rvb_signals.jsonl en logs/charts. Pagina gegenereerd {d['generated_at']}.</p>
</div><script>{JS}</script></body></html>"""


# ---------------------------------------------------------------------------
# HTTP
# ---------------------------------------------------------------------------

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        url = urlparse(self.path)
        q = parse_qs(url.query)
        if url.path == "/health":
            return self._send(200, b"ok", "text/plain")
        if url.path.startswith("/charts/"):
            return self._send_chart(url.path[len("/charts/"):])
        try:
            day = date.fromisoformat(q.get("date", [date.today().isoformat()])[0])
        except ValueError:
            return self._send(400, b"ongeldige datum", "text/plain")
        data = build_day(day, load_trades())
        if url.path == "/api/day":
            return self._send(200, json.dumps(data, default=str).encode(), "application/json")
        if url.path == "/":
            return self._send(200, render(data).encode(), "text/html; charset=utf-8")
        self._send(404, b"niet gevonden", "text/plain")

    def _send_chart(self, name: str):
        safe = os.path.basename(name)
        pad = os.path.join(CHARTS_DIR, safe)
        if not safe.endswith(".png") or not os.path.isfile(pad):
            return self._send(404, b"geen grafiek", "text/plain")
        with open(pad, "rb") as f:
            self._send(200, f.read(), "image/png", cache="max-age=86400")

    def _send(self, code: int, body: bytes, ctype: str, cache: str = "no-store"):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", cache)
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, fmt, *args):
        sys.stderr.write(f"{self.log_date_time_string()} {self.address_string()} {fmt % args}\n")


if __name__ == "__main__":
    print(f"Dashboard op http://{HOST}:{PORT} (journal: {JOURNAL_PATH})")
    HTTPServer((HOST, PORT), Handler).serve_forever()
